from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # For flash messages

# Configure upload folder
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Add status color filter
@app.template_filter('status_color')
def status_color(status):
    return {
        'pending': 'warning',
        'processing': 'info',
        'completed': 'success',
        'cancelled': 'danger'
    }.get(status, 'secondary')

def get_db():
    conn = sqlite3.connect('orders.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with app.app_context():
        db = get_db()
        db.execute('''
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                phone_number TEXT NOT NULL,
                order_date TEXT NOT NULL,
                status TEXT NOT NULL,
                total REAL NOT NULL,
                items TEXT NOT NULL,
                photo_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        db.commit()

@app.route('/')
def index():
    db = get_db()
    search = request.args.get('search', '')
    status_filter = request.args.get('status', '')

    query = "SELECT * FROM orders WHERE 1=1"
    params = []

    if search:
        query += " AND (customer_name LIKE ? OR items LIKE ? OR phone_number LIKE ?)"
        search_param = f'%{search}%'
        params.extend([search_param, search_param, search_param])

    if status_filter:
        query += " AND status = ?"
        params.append(status_filter)

    query += " ORDER BY created_at DESC"
    orders = db.execute(query, params).fetchall()
    return render_template('orders/list.html', orders=orders, search=search, status_filter=status_filter)

@app.route('/order/new', methods=['GET', 'POST'])
def create_order():
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        phone_number = request.form['phone_number']
        items = request.form['items']
        total = float(request.form['total'])
        photo = request.files.get('photo')
        photo_path = None

        if not customer_name or not items or not phone_number or total <= 0:
            flash('Please fill all required fields correctly', 'error')
            return redirect(url_for('create_order'))

        if photo and allowed_file(photo.filename):
            filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{photo.filename}"
            photo_path = os.path.join('uploads', filename)
            photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

        db = get_db()
        db.execute('''
            INSERT INTO orders (customer_name, phone_number, order_date, status, total, items, photo_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (customer_name, phone_number, datetime.now().strftime('%Y-%m-%d'), 'pending', total, items, photo_path))
        db.commit()
        flash('Order created successfully!', 'success')
        return redirect(url_for('index'))

    return render_template('orders/create.html')

@app.route('/order/<int:order_id>')
def order_detail(order_id):
    db = get_db()
    order = db.execute('SELECT * FROM orders WHERE id = ?', [order_id]).fetchone()
    if order is None:
        flash('Order not found', 'error')
        return redirect(url_for('index'))
    return render_template('orders/detail.html', order=order)

@app.route('/order/<int:order_id>/status', methods=['POST'])
def update_status(order_id):
    new_status = request.form['status']
    if new_status not in ['pending', 'processing', 'completed', 'cancelled']:
        return jsonify({'error': 'Invalid status'}), 400

    db = get_db()
    db.execute('UPDATE orders SET status = ? WHERE id = ?', [new_status, order_id])
    db.commit()
    return jsonify({'success': True})

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=8000, debug=True)