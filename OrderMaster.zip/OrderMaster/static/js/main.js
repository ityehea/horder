// Form validation
document.addEventListener('DOMContentLoaded', function() {
    // Enable Bootstrap form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });

    // Status update handling
    const statusLinks = document.querySelectorAll('.status-update');
    statusLinks.forEach(link => {
        link.addEventListener('click', async (e) => {
            e.preventDefault();
            const orderId = link.dataset.orderId;
            const newStatus = link.dataset.status;
            
            showSpinner();
            
            try {
                const response = await fetch(`/order/${orderId}/status`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `status=${newStatus}`
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Update status badge
                    const badge = document.getElementById('status-badge');
                    if (badge) {
                        badge.textContent = newStatus;
                        badge.className = `badge bg-${newStatus}`;
                    }
                    
                    showToast('Status updated successfully', 'success');
                } else {
                    showToast('Failed to update status', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            } finally {
                hideSpinner();
            }
        });
    });
});

// Spinner functions
function showSpinner() {
    const spinner = document.createElement('div');
    spinner.className = 'spinner-overlay';
    spinner.innerHTML = `
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    `;
    document.body.appendChild(spinner);
    spinner.style.display = 'flex';
}

function hideSpinner() {
    const spinner = document.querySelector('.spinner-overlay');
    if (spinner) {
        spinner.remove();
    }
}

// Toast notification
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show position-fixed bottom-0 end-0 m-3`;
    toast.style.zIndex = '1050';
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}
